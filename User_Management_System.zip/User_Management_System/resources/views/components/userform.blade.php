<input type="{{$type}}" class="form-control" name="{{$name}}" id="{{$id}}" placeholder="{{$placeholder}}">
